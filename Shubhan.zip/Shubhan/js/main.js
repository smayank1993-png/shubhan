// Initiate the wowjs animation library
  new WOW().init();